# Error Path Enumeration — EquiGuard (`geofence-processor`)

**Guidelines Reference:** [BDD Guidelines v1.9.0 §4.5 (Systematic Identification of Failure Paths)](../../BDD_GUIDELINES_v1.9.0_EN.md)
**Accountable ADRs:** [ADR-0001](../governance/adr/0001-point-in-polygon-ray-casting.md), [ADR-0005](../governance/adr/0005-points-on-the-fence-count-as-inside.md), [ADR-0002](../governance/adr/0002-event-driven-pubsub-push-to-cloud-run.md), [ADR-0003](../governance/adr/0003-firestore-persistence-and-alert-schema.md), [ADR-0004](../governance/adr/0004-language-neutral-black-box-test-harness.md)

Before writing individual failure scenarios, we decompose `geofence-processor` along its processing layers and enumerate the error and boundary space systematically.

---

## Summary Table

| Layer | Total Identified | Covered by Scenario (`exec`) | Excluded / Deferred (`none`) |
|---|---:|---:|---:|
| 1. Geometry & Boundary Evaluation (`@mi1`) | 9 | 8 | 1 |
| 2. Payload & Input Validation (`@mi3`) | 5 | 3 | 2 |
| 3. State & Persistence Behavior (`@mi2`–`@mi4`) | 3 | 2 | 1 |
| 4. Container & Cloud Runtime (`@mi3`–`@mi4`) | 3 | 3 | 0 |
| **Total** | **20** | **16** | **4** |

---

## Layer-by-Layer Enumeration

### Layer 1: Geometry & Boundary Evaluation ([ADR-0001](../governance/adr/0001-point-in-polygon-ray-casting.md), [ADR-0005](../governance/adr/0005-points-on-the-fence-count-as-inside.md))

| ID | Case / Boundary | Expected Behavior | Status | Covering Scenario / Reason |
|---|---|---|---|---|
| 1.1 | Point strictly inside a convex polygon (`HomePasture`) | Returns `is_inside = true` (3 variance points) | `exec` | `mi1_geofence_library.feature`: *Validate if a telemetry point is inside or outside the geofence* (`telemetry_in_01`..`03`) |
| 1.2 | Point strictly outside a convex polygon (`HomePasture`) | Returns `is_inside = false` (3 variance points: south, north-west, north-east) | `exec` | `mi1_geofence_library.feature`: *Validate if a telemetry point is inside or outside the geofence* (`telemetry_out_01`..`03`) |
| 1.3 | Point inside a concave polygon with interior indentation (`ComplexPasture`) | Returns `is_inside = true` (6 variance points across arms) | `exec` | `mi1_geofence_library.feature`: *Validate complex concave geofence with interior exclusions* (`telemetry_in_01`..`06`) |
| 1.4 | Point inside the concave cutout / outside the concave polygon (`ComplexPasture`) | Returns `is_inside = false` (4 variance points, including points inside the concave bay) | `exec` | `mi1_geofence_library.feature`: *Validate complex concave geofence with interior exclusions* (`telemetry_out_01`..`04`) |
| 1.5 | Point exactly on a polygon vertex (`HomePasture`, 4 vertices) | Returns `is_inside = true` ([ADR-0005](../governance/adr/0005-points-on-the-fence-count-as-inside.md)) | `exec` | `mi1_geofence_library.feature`: *A point on the fence counts as inside the pasture* (`on_vertex_1`..`4`) |
| 1.6 | Point exactly on a polygon edge (`HomePasture`, edge midpoints) | Returns `is_inside = true` ([ADR-0005](../governance/adr/0005-points-on-the-fence-count-as-inside.md)) | `exec` | `mi1_geofence_library.feature`: *A point on the fence counts as inside the pasture* (`on_edge_south`, `on_edge_east`, `on_edge_north`, `on_edge_north_west`) |
| 1.7 | Point `1e-6` degrees (about 0.1 m) beyond or inside the fence (negative control for the `1e-9` tolerance) | Beyond: `is_inside = false`; inside: `is_inside = true` | `exec` | `mi1_geofence_library.feature`: *A point on the fence counts as inside the pasture* (`just_outside_*`, `just_inside_*`) |
| 1.8 | Point half the `1e-9` degree tolerance beyond the fence (within) and twice the tolerance beyond it, at an edge and at a vertex | Within: `is_inside = true`; beyond: `is_inside = false` ([ADR-0005](../governance/adr/0005-points-on-the-fence-count-as-inside.md)) | `exec` | `mi1_geofence_library.feature`: *A point on the fence counts as inside the pasture* (`within_tolerance_*`, `beyond_tolerance_*`) |
| 1.9 | GPS position jitter of a few metres around the fence | No tolerance band in V1 | `none` | Deferred: [LIM-0004](../governance/limitations/0004-gps-accuracy-not-modelled.md) |

### Layer 2: Payload & Input Validation ([ADR-0002](../governance/adr/0002-event-driven-pubsub-push-to-cloud-run.md))

| ID | Failure Source | Expected Behavior | Status | Covering Scenario / Reason |
|---|---|---|---|---|
| 2.1 | Missing `lon` / `lat` coordinates in telemetry payload (`{"zone": "HomePasture"}`) | HTTP `400 Bad Request`; `alerts` collection remains empty | `exec` | `mi3_geofence_processor_image.feature`: *Container rejects requests with missing mandatory fields* (`missing lon/lat`) |
| 2.2 | Missing `zone` field in telemetry payload (`{"lon": 9.6116704, "lat": 53.2275266}`) | HTTP `400 Bad Request`; `alerts` collection remains empty | `exec` | `mi3_geofence_processor_image.feature`: *Container rejects requests with missing mandatory fields* (`missing zone`) |
| 2.3 | Empty telemetry JSON payload (`{}`) | HTTP `400 Bad Request`; `alerts` collection remains empty | `exec` | `mi3_geofence_processor_image.feature`: *Container rejects requests with missing mandatory fields* (`empty body`) |
| 2.4 | Invalid base64 or malformed outer Pub/Sub envelope | HTTP `400 Bad Request`, no Firestore write ([ADR-0002](../governance/adr/0002-event-driven-pubsub-push-to-cloud-run.md)) | `none` | Scenario deferred: [LIM-0003](../governance/limitations/0003-unknown-zone-unspecified-malformed-envelope-untested.md); the outer envelope is generated by managed GCP Pub/Sub |
| 2.5 | Unknown `zone` not found in Firestore `geofences` collection | Unspecified in V1 | `none` | Deferred: [LIM-0003](../governance/limitations/0003-unknown-zone-unspecified-malformed-envelope-untested.md); V1 assumes `geofences/<zone>` is seeded before collar activation |

### Layer 3: State & Persistence Behavior ([ADR-0003](../governance/adr/0003-firestore-persistence-and-alert-schema.md))

| ID | Case | Expected Behavior | Status | Covering Scenario / Reason |
|---|---|---|---|---|
| 3.1 | Horse ping is outside assigned pasture (`Lilly`) | Writes `GEOFENCE_VIOLATION` alert document for `Lilly` in Firestore `alerts` collection | `exec` | `mi2`, `mi3`, `mi4`: *Alert when a horse leaves the pasture* |
| 3.2 | Horse ping is inside assigned pasture (`Honey` — Negative Control per §4.2) | Does **not** write any alert document for `Honey` in Firestore `alerts` collection | `exec` | `mi2`, `mi3`, `mi4`: *No alert when a horse remains inside the pasture* |
| 3.3 | Consecutive outside pings / Pub/Sub redelivery for the same horse | Writes one alert per outside ping (stateless evaluation) | `none` | Documented as deliberate V1 boundary in [LIM-0002](../governance/limitations/0002-stateless-per-ping-evaluation-without-deduplication.md) |

### Layer 4: Container & Cloud Runtime ([ADR-0002](../governance/adr/0002-event-driven-pubsub-push-to-cloud-run.md), [ADR-0004](../governance/adr/0004-language-neutral-black-box-test-harness.md))

| ID | Check | Expected Behavior | Status | Covering Scenario / Reason |
|---|---|---|---|---|
| 4.1 | Container startup and readiness (`GET /health`) | Responds HTTP `200` within 10s locally (`@mi3`) and 30s on Cloud Run cold start (`@mi4`) | `exec` | `mi3`: *Container starts and becomes healthy*; `mi4`: *Service is reachable and healthy on Cloud Run* |
| 4.2 | Container port binding (`8081`) | Container listens on configured port `8081` | `exec` | `mi3`: *Container image exposes the correct port* |
| 4.3 | End-to-end cloud IAM & Pub/Sub push delivery on GCP (`@mi4`) | Real Pub/Sub topic pushes to Cloud Run and writes to real Firestore | `exec` | `mi4`: *Alert when a horse leaves the pasture via real Pub/Sub* |
