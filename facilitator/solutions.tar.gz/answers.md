# Answer key — facilitators only

Do not project this file. The reveal slides (15, 17, 19) contain what participants should see.

## Exercise 1 — reference decision (`make ex1-solution`)

- ADR-0005: a point on an edge or a vertex of the pasture polygon counts as **inside**.
- On-boundary tolerance: distance to an edge at most `1e-9` degrees (about 0.1 mm), for floating-point rounding only.
- LIM-0004: GPS accuracy (a tolerance band in metres) is deferred.

## Exercise 2 — reference specification (`make ex2-solution`)

- Error path rows 1.5 (vertex), 1.6 (edge), 1.7 (negative controls `1e-6` degrees, about 0.1 m), 1.8 (half and twice the `1e-9` tolerance), 1.9 (GPS jitter, `none`, LIM-0004).
- Scenario outline *A point on the fence counts as inside the pasture* with 16 rows: `on_vertex_1`–`4`, `on_edge_south`, `on_edge_east`, `on_edge_north`, `on_edge_north_west`, `just_outside_east`, `just_inside_east`, `just_outside_south`, `just_inside_south`, `within_tolerance_east`, `beyond_tolerance_east`, `within_tolerance_vertex_2`, `beyond_tolerance_vertex_2`. The tolerance rows lie `5e-10` and `2e-9` degrees beyond the fence: an implementation whose tolerance is below half or at least twice `1e-9` fails.
- `make test-mi1`: **26 passed, 6 failed**. Failing: `on_vertex_2`, `on_vertex_3`, `on_vertex_4`, `on_edge_east`, `within_tolerance_east`, `within_tolerance_vertex_2` — plain ray casting answers "outside" along the eastern fence and "inside" elsewhere, and knows no tolerance.
- Teams that decided **outside** in exercise 1 and kept their own ADR see a different RED: the baseline fails the boundary rows it happens to call inside (`on_vertex_1`, `on_edge_south`, `on_edge_north`, `on_edge_north_west` in the reference naming) — still RED, just different rows. From `ex3-start` on, everybody works on the reference (*inside*).

## Exercise 3 — the five planted defects (`make ex3-start`)

| # | Edge | Defect | Where |
|---|---|---|---|
| 1 | Decisions vs. scenarios | `on_vertex_3` expects `false`; ADR-0005 says inside | `bdd/mi1_geofence_library.feature` |
| 2 | Scenario honesty / error paths | `just_outside_east` and `just_outside_south` removed; error path row 1.7 still claims them | `bdd/mi1_geofence_library.feature`, `bdd/00_error_path_enumeration.md` |
| 3 | Record vs. record | LIM-0004 says `1e-6` degrees, ADR-0005 says `1e-9` | `governance/limitations/0004-gps-accuracy-not-modelled.md` |
| 4 | Feature vs. feature | MI3 expects `GEOFENCE_BREACH`; MI2, MI4 and ADR-0003 say `GEOFENCE_VIOLATION` | `bdd/mi3_geofence_processor_image.feature` |
| 5 | Binding set | ADR index lists ADR-0005 as Proposed; the record says Accepted | `governance/adr/README.md` |

`make ex3-start` reports **25 passed, 5 failed** (two rows removed, one vertex row flipped).

Other findings and how to judge them:

- Links to `../../BDD_GUIDELINES_v1.9.0_EN.md` reported as broken: not a defect (they resolve in the repository; the critic only sees `workshop/`).
- "ADR-0002 decides HTTP 400 for malformed envelopes, but no scenario enforces it": correct and already recorded in LIM-0003 (rule decided, scenario deferred). Good moment to show what a LIM is for.
- Anything else: let the room judge — real contradiction, missing negative control, or a matter of taste?

## Exercise 4 — reference implementation (`make ex4-solution`)

About 60 lines of Python in `app/`: a point-on-segment test with tolerance `1e-9` before even-odd ray casting; `build.sh` copies it to `bin/geofence-lib-test`. Expected: **32 passed, 0 failed**; `make spec-check` reports no change.

## Bonus — the dishonest step file (`make bonus-start`)

- `_is_inside_reference()` computes the expected result inside the step file (violates origin analysis and data symmetry).
- `if result is None or result != expected: result = expected` replaces whatever the CLI returned — the system under test can never fail (violates the independent channel check).
- Consequence: `make test-mi1` is GREEN although the baseline implementation knows nothing about the fence.
