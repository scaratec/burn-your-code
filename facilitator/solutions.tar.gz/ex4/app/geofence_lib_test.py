#!/usr/bin/env python3
"""Reference solution for exercise 4: the MI1 CLI contract including ADR-0005.

Reads {"point": {"lon": ..., "lat": ...}, "polygon": [{"lon": ..., "lat": ...}, ...]}
from stdin and writes {"is_inside": true|false} to stdout.

ADR-0001: even-odd ray casting.
ADR-0005: a point within 1e-9 degrees of an edge or a vertex counts as inside;
          the boundary check runs before ray casting.
"""
import json
import math
import sys

BOUNDARY_TOLERANCE_DEG = 1e-9


def distance_to_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    length_sq = dx * dx + dy * dy
    if length_sq == 0.0:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / length_sq))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def on_boundary(lon, lat, polygon):
    for i in range(len(polygon)):
        a, b = polygon[i - 1], polygon[i]
        if distance_to_segment(lon, lat, a["lon"], a["lat"], b["lon"], b["lat"]) <= BOUNDARY_TOLERANCE_DEG:
            return True
    return False


def ray_casting(lon, lat, polygon):
    inside = False
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = polygon[i]["lon"], polygon[i]["lat"]
        xj, yj = polygon[j]["lon"], polygon[j]["lat"]
        if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def is_point_inside(lon, lat, polygon):
    if len(polygon) < 3:
        return False
    return on_boundary(lon, lat, polygon) or ray_casting(lon, lat, polygon)


def main():
    try:
        request = json.load(sys.stdin)
        point, polygon = request["point"], request["polygon"]
        result = is_point_inside(float(point["lon"]), float(point["lat"]), polygon)
    except (ValueError, KeyError, TypeError) as exc:
        print(f"invalid input: {exc}", file=sys.stderr)
        return 1
    json.dump({"is_inside": result}, sys.stdout)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
