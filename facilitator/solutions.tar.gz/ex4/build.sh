#!/usr/bin/env bash
# Reference build for exercise 4: installs the Python implementation as ./bin/geofence-lib-test.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p bin
cp src/geofence_lib_test.py bin/geofence-lib-test
chmod +x bin/geofence-lib-test
