# LIM 0004: V1 does not model GPS accuracy around the fence

- **Status:** Accepted
- **Resolution intent:** must-resolve (technical debt)
- **Date proposed:** 2026-11-14
- **Date approved:** 2026-11-14
- **Proposed by:** EquiGuard Architecture Team
- **Approved by:** Workshop Lead
- **Scope:** point-in-polygon evaluation (`geofence-lib-test`, `geofence-processor`)
- **Related ADRs:** [ADR-0001](../adr/0001-point-in-polygon-ray-casting.md), [ADR-0005](../adr/0005-points-on-the-fence-count-as-inside.md)
- **Related Guidelines:** BDD Guidelines v1.9.0 §4.5 (error path enumeration), §14 (Specification Critic)

## Resolution intent

**Classification: must-resolve.**

V1 treats every reported coordinate as exact. Only points within the numerical tolerance of `1e-9` degrees of an edge count as "on the fence" ([ADR-0005](../adr/0005-points-on-the-fence-count-as-inside.md)). A real GPS collar is only accurate to a few metres, so a horse standing at the fence may be reported a little inside or a little outside.

## Context

A tolerance band around the fence (for example "within 3 m counts as inside") would need a metric distance between longitude/latitude coordinates (a map projection or a geodesic formula) and accuracy data per collar. Neither is part of the V1 telemetry payload (`device`, `lon`, `lat`, `timestamp`, `zone`).

## Nature of the weakness

- A horse at the fence whose reported position jitters by one or two metres can produce alternating inside/outside results and therefore alerts.
- The `1e-9` degree tolerance is about 0.1 mm. It exists only to absorb floating-point rounding and must not be mistaken for GPS accuracy.

## Why the clean solution is not chosen

Exact geometry keeps the MI1 scenarios small and deterministic: a point exactly on a vertex or an edge midpoint is inside, a point `1e-6` degrees (about 0.1 m) beyond the edge is outside. A metric tolerance band would add a projection decision and accuracy data that V1 does not have.

## Mitigations in place

1. [ADR-0005](../adr/0005-points-on-the-fence-count-as-inside.md) makes the boundary case deterministic: on the fence counts as inside.
2. The feature file specifies the boundary with exact points and a negative control just outside the fence, so an implementation cannot silently widen the tolerance.
3. An AI agent reading this LIM knows **not** to invent a tolerance band in metres.

## Residual risk

Alert flapping for horses grazing directly at the fence, made worse by the stateless evaluation of [LIM-0002](0002-stateless-per-ping-evaluation-without-deduplication.md).

## Triggers for revisit

- Collars that report a horizontal accuracy value.
- Operator complaints about repeated alerts for horses standing at the fence.

## References

- [ADR-0005](../adr/0005-points-on-the-fence-count-as-inside.md)
- [`bdd/mi1_geofence_library.feature`](../../bdd/mi1_geofence_library.feature)
