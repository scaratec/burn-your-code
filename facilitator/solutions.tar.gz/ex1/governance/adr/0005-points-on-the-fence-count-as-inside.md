# ADR 0005: A point on the fence counts as inside the pasture

- **Status:** Accepted
- **Date:** 2026-11-14
- **Deciders:** EquiGuard Architecture Team

## Context

[ADR-0001](0001-point-in-polygon-ray-casting.md) decides *how* we test a point against the pasture polygon (even-odd ray casting). It does not decide what happens when a GPS point lies **exactly on the fence**, that is, on an edge or on a vertex of the polygon.

Ray casting is ambiguous there: whether the ray "crosses" an edge it starts on depends on implementation details such as `<` versus `<=`. Two correct-looking implementations can return different answers for the same point, and nothing in the specification would tell which one is right. Points on the fence are not exotic: operators often place polygon vertices on fence posts, and the collars of horses grazing along the fence report positions close to it.

## Decision

We treat every point that lies on the boundary of the pasture polygon (on an edge or on a vertex) as **inside** (`is_inside = true`), and evaluate ray casting only for points that are not on the boundary.

- A point lies on the boundary if its distance to at least one polygon edge is at most **`1e-9` degrees** (about 0.1 mm). This numerical tolerance only absorbs floating-point rounding; it is not a GPS accuracy band (see [LIM-0004](../limitations/0004-gps-accuracy-not-modelled.md)).
- The boundary check runs before ray casting, so the result no longer depends on how an implementation treats rays that touch a vertex or run along an edge.

## Consequences

### Positive

- One unambiguous answer for points on the fence, testable with points placed exactly on vertices and on edge midpoints.
- A horse standing at the fence has not left the pasture, so the system raises no alert for it.

### Negative

- Every implementation needs an explicit point-on-segment test in addition to ray casting (a few more lines of code).
- A horse that is really already one step outside but reported on the fence line raises no alert.

### Neutral

- Points just next to the fence (for example `1e-6` degrees, about 0.1 m, away from an edge) are evaluated by ray casting as before.

## Security Implications

The decision changes a pure in-memory computation only. It adds no endpoint, credential, data flow or trust boundary and logs no data. Erring towards "inside" can suppress an alert for a horse exactly on the fence; this is a safety trade-off, not a security one, and it is bounded by [LIM-0004](../limitations/0004-gps-accuracy-not-modelled.md).

## Alternatives Considered

- **A point on the fence counts as outside (alert).** Rejected because a horse grazing along the fence would trigger alerts although it never left the pasture, which erodes trust in the alerts.
- **Leave the result to the implementation.** Rejected because two implementations could disagree and no scenario could decide which is right, so the code would no longer be replaceable.
- **A tolerance band around the fence (for example 1 m).** Rejected for V1 because it needs a metric projection of longitude and latitude and real GPS accuracy data; recorded as [LIM-0004](../limitations/0004-gps-accuracy-not-modelled.md).

## References

- Refines: [ADR-0001](0001-point-in-polygon-ray-casting.md)
- Enforced by: [`bdd/mi1_geofence_library.feature`](../../bdd/mi1_geofence_library.feature) (*A point on the fence counts as inside the pasture*)
- Bounded by: [LIM-0004](../limitations/0004-gps-accuracy-not-modelled.md)
