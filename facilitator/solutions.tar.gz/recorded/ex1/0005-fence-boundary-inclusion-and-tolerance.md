# ADR 0005: Fence boundary inclusion and numerical tolerance for geofence evaluation

- **Status:** Accepted
- **Date:** 2026-11-13
- **Deciders:** EquiGuard Architecture Team

## Context

[ADR-0001](0001-point-in-polygon-ray-casting.md) establishes the even-odd ray-casting algorithm to determine whether a telemetry coordinate `(lon, lat)` lies inside or outside a closed pasture polygon. Standard ray casting is mathematically ambiguous when a test point lies precisely on a polygon boundary (i.e., on an edge or coinciding with a vertex), because a horizontal ray may pass through a vertex or be collinear with an edge, producing indeterminate or implementation-dependent intersection counts.

Furthermore, coordinates are represented as IEEE-754 double-precision floating-point numbers (`lon`, `lat`). Due to floating-point rounding errors during coordinate parsing and geometric calculations, exact mathematical coincidence on a line segment is rare and sensitive to arithmetic ordering.

Without an explicit architecture decision, different polyglot implementations (Go, Python, Rust, TypeScript, Java) could classify boundary points differently, leading to inconsistent escape alerts or test divergence.

## Decision

We resolve boundary ambiguity by defining that points on the fence boundary are **inside** the pasture, evaluated with a strict numerical tolerance in degrees:

1. **Boundary Inclusion:** Any GPS point lying on a polygon edge or vertex counts as **inside** the pasture (`is_inside: true`). No escape alert is generated.
2. **Numerical Tolerance:** A point is classified as lying on an edge or vertex if its distance to a vertex or perpendicular distance to an edge segment (within segment bounds) is within a numerical tolerance of **$\epsilon = 10^{-9}$ degrees** (approx. $0.11\text{ mm}$ at the equator). This tolerance purely absorbs IEEE-754 floating-point rounding error.
3. **Physical GPS Tolerance:** Physical GPS collar accuracy error bands in meters are not modeled in V1 and are deferred to [LIM-0004](../limitations/0004-planar-evaluation-without-gps-accuracy-buffer.md).

## Consequences

### Positive

- Deterministic behavior: All polyglot implementations across Go, Python, Rust, TypeScript, and Java yield identical binary results (`is_inside: true|false`) for edge and vertex test points.
- False-alarm reduction: Grazing horses standing at or leaning against the perimeter fence line do not trigger false `GEOFENCE_VIOLATION` alerts.
- Precision separation: Pure floating-point numerical tolerance ($\epsilon = 10^{-9}$ degrees) is strictly decoupled from physical spatial buffer zones.

### Negative

- Ray-casting implementations must include an explicit boundary/collinearity check against polygon segments before or alongside ray intersection testing.

### Neutral

- An alert will only be emitted once a coordinate has strictly passed beyond the $\epsilon = 10^{-9}$ degree boundary threshold.

## Security Implications

Boundary evaluation remains a pure, in-memory geometric function with no I/O, no state, and no network dependencies. Setting an explicit numerical tolerance prevents denial-of-service or assertion panics caused by edge-case division-by-zero or non-deterministic floating-point branching across runtime platforms.

## Alternatives Considered

- **Treating boundary points as outside (`is_inside: false`).** Rejected because it produces false-positive escape alerts whenever animals graze along the perimeter fence line.
- **Introducing a distinct third classification state (`warning` / `on_fence`).** Rejected because it breaks the binary boolean interface (`is_inside: true|false`) required by the Milestone 1 CLI specification and complicates downstream Firestore alert handling.
- **Zero tolerance ($\epsilon = 0.0$ / exact equality).** Rejected because IEEE-754 floating-point arithmetic rounding discrepancies across compilers and architectures would produce flaky, non-portable results.
- **Larger degree epsilon ($\epsilon = 10^{-7}$ degrees $\approx 1.1\text{ cm}$).** Rejected because it conflates numerical rounding tolerance with physical distance buffers.

## References

- [ADR-0001](0001-point-in-polygon-ray-casting.md)
- [LIM-0004](../limitations/0004-planar-evaluation-without-gps-accuracy-buffer.md)
- [BDD Guidelines v1.9.0](../../BDD_GUIDELINES_v1.9.0_EN.md) §2.1
