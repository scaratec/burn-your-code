# LIM 0004: V1 evaluates GPS pings as exact planar points without meter-based accuracy buffers

- **Status:** Accepted
- **Resolution intent:** must-resolve (technical debt)
- **Date proposed:** 2026-11-13
- **Date approved:** 2026-11-13
- **Proposed by:** EquiGuard Architecture Team
- **Approved by:** Workshop Lead
- **Scope:** `geofence-lib` and `geofence-processor` boundary evaluation
- **Related ADRs:** [ADR-0001](../adr/0001-point-in-polygon-ray-casting.md), [ADR-0005](../adr/0005-fence-boundary-inclusion-and-tolerance.md)
- **Related Guidelines:** BDD Guidelines v1.9.0 §4.5 (Error Path Enumeration), §14 (Specification Critic)

## Resolution intent

**Classification: must-resolve.**

V1 of EquiGuard evaluates GPS coordinates strictly as planar mathematical points `(lon, lat)` against the pasture polygon. Modeling real-world GPS measurement inaccuracy (such as an error band in meters or dynamic collar HDOP dilution of precision) is deferred to a future milestone.

## Context

Physical GPS collars experience measurement jitter and atmospheric drift, typically resulting in positioning errors between $\pm 2$ and $\pm 10$ meters. In production livestock monitoring, geofences often employ a geodesic tolerance buffer (e.g., $\pm 5$ meters) or evaluate probability distributions based on collar accuracy metrics before triggering escape alerts.

However, converting meter-based buffer distances across latitude and longitude requires geodesic or spherical calculations (e.g., Haversine/Vincenty formulas or map projections), which adds substantial geometric complexity. [ADR-0001](../adr/0001-point-in-polygon-ray-casting.md) and [ADR-0005](../adr/0005-fence-boundary-inclusion-and-tolerance.md) establish a planar ray-casting algorithm operating directly on degree coordinates with only a $10^{-9}$ degree numerical rounding tolerance.

## Nature of the weakness

- **No physical buffer band:** A horse standing 1 meter inside the fence whose collar drifts 2 meters outward will be classified as outside (`is_inside: false`), triggering a `GEOFENCE_VIOLATION` alert.
- **Collar accuracy metadata ignored:** Any accuracy radius or HDOP values emitted by hardware collars are discarded during ingestion.

## Why the clean solution is not chosen

Implementing geodesic meter buffers requires external GIS dependencies or non-trivial spherical trigonometry. Keeping V1 evaluation to planar ray casting on raw degree coordinates preserves the core constraint that the geofence engine can be implemented in ~25 lines of pure code in any programming language without external dependencies.

## Mitigations in place

1. [ADR-0005](../adr/0005-fence-boundary-inclusion-and-tolerance.md) classifies points lying on the fence line (within $10^{-9}$ degrees) as inside, preventing false alerts for points directly on the boundary.
2. Operators in V1 can draw pasture boundaries with a manual outward margin in Firestore master data if required.
3. The limitation is explicitly documented so implementing AI agents do not attempt to add geodesic distance approximations or external GIS libraries.

## Residual risk

Horses grazing very close to the physical perimeter fence may periodically generate false-positive breach alerts due to satellite positioning drift.

## Triggers for revisit

- Field deployment reports showing unacceptable false-alarm rates for animals grazing near boundary fences.
- Upgrading collar hardware to report standardized horizontal accuracy metrics (HDOP/CEP).

## References

- [ADR-0001](../adr/0001-point-in-polygon-ray-casting.md)
- [ADR-0005](../adr/0005-fence-boundary-inclusion-and-tolerance.md)
