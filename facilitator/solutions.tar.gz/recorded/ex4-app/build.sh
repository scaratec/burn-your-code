#!/usr/bin/env bash
set -euo pipefail

# Build / install geofence-lib-test CLI for Milestone 1
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$SCRIPT_DIR/bin"

cat << 'EOF' > "$SCRIPT_DIR/bin/geofence-lib-test"
#!/usr/bin/env python3
import sys
from pathlib import Path

# Add repository root to sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from app.cli import main

if __name__ == "__main__":
    main()
EOF

chmod +x "$SCRIPT_DIR/bin/geofence-lib-test"
