"""EquiGuard Geofence Evaluation Library.

Implements point-in-polygon evaluation via:
- ADR-0001: Even-odd ray casting algorithm (Jordan curve theorem).
- ADR-0005: Points on the fence (within 1e-9 degrees of an edge/vertex) count as inside.
"""

import math
from typing import Any, Dict, List, Tuple


TOLERANCE_DEGREES: float = 1e-9


def distance_point_to_segment(
    px: float, py: float, ax: float, ay: float, bx: float, by: float
) -> float:
    """Calculate the Euclidean distance in degrees from point P to line segment AB."""
    dx = bx - ax
    dy = by - ay
    l2 = dx * dx + dy * dy
    if l2 == 0.0:
        return math.hypot(px - ax, py - ay)

    # Projection parameter t clamped to segment [0, 1]
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / l2))
    proj_x = ax + t * dx
    proj_y = ay + t * dy
    return math.hypot(px - proj_x, py - proj_y)


def extract_edges(polygon: List[Dict[str, Any]]) -> List[Tuple[Dict[str, Any], Dict[str, Any]]]:
    """Extract consecutive edges from polygon vertex list, closing it if needed."""
    n = len(polygon)
    if n < 3:
        return []

    edges = []
    for i in range(n - 1):
        edges.append((polygon[i], polygon[i + 1]))

    # Ensure polygon is closed
    first, last = polygon[0], polygon[-1]
    if float(first["lon"]) != float(last["lon"]) or float(first["lat"]) != float(last["lat"]):
        edges.append((last, first))

    return edges


def is_point_inside(
    point: Dict[str, Any],
    polygon: List[Dict[str, Any]],
    tolerance: float = TOLERANCE_DEGREES,
) -> bool:
    """Determine whether point is inside the polygon or on its boundary.

    1. Boundary check: If point is within tolerance (1e-9 degrees) of any edge,
       it is considered on the fence and inside (ADR-0005).
    2. Ray casting: Cast a horizontal ray to the right (+lon) and test parity
       of edge crossings (ADR-0001).
    """
    edges = extract_edges(polygon)
    if not edges:
        return False

    px = float(point["lon"])
    py = float(point["lat"])

    # 1. Boundary check (ADR-0005)
    for p1, p2 in edges:
        x1, y1 = float(p1["lon"]), float(p1["lat"])
        x2, y2 = float(p2["lon"]), float(p2["lat"])
        if distance_point_to_segment(px, py, x1, y1, x2, y2) <= tolerance:
            return True

    # 2. Ray casting (ADR-0001)
    inside = False
    for p1, p2 in edges:
        x1, y1 = float(p1["lon"]), float(p1["lat"])
        x2, y2 = float(p2["lon"]), float(p2["lat"])
        if (y1 > py) != (y2 > py):
            x_int = x1 + (py - y1) * (x2 - x1) / (y2 - y1)
            if px < x_int:
                inside = not inside

    return inside
