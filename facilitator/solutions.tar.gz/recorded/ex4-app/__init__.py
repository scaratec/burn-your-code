"""EquiGuard Application Package."""
