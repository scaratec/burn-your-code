#!/usr/bin/env python3
"""EquiGuard Geofence Library CLI (Milestone 1).

Reads JSON from stdin:
    {"point": {"lon": <float>, "lat": <float>}, "polygon": [{"lon": <float>, "lat": <float>}, ...]}
Writes JSON to stdout:
    {"is_inside": true|false}

Complies with ADR-0001, ADR-0004, and ADR-0005.
"""

import json
from pathlib import Path
import sys

# Ensure repository root is on sys.path so app package imports work
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.geofence import is_point_inside


def main() -> None:
    raw_input = sys.stdin.read()
    if not raw_input.strip():
        sys.stderr.write("Error: empty input on stdin\n")
        sys.exit(1)

    try:
        data = json.loads(raw_input)
    except json.JSONDecodeError as exc:
        sys.stderr.write(f"Error: invalid JSON on stdin: {exc}\n")
        sys.exit(1)

    point = data.get("point")
    polygon = data.get("polygon")

    if point is None or polygon is None:
        sys.stderr.write("Error: input must contain 'point' and 'polygon' keys\n")
        sys.exit(1)

    result = is_point_inside(point, polygon)
    sys.stdout.write(json.dumps({"is_inside": result}) + "\n")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
