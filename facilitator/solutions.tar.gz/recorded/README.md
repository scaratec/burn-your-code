# Recorded agent output (dry runs with gemini-3.8-flash-high)

For the offline fallback and for preparing the debriefs. Each file is the unedited output of one clean dry run on the current material (fresh clone, fresh agent home).

| File | Exercise | Run |
|---|---|---|
| `ex1/dialogue.txt`, `ex1/0005-*.md`, `ex1/0004-*.md` | 1 — dialogue (answers: inside, 1e-9, defer) and the records it wrote | interactive, 2:34 including the answers |
| `ex2-agent.txt`, `ex2-spec.diff` | 2 — report and the error paths and scenarios it added | 6:08, 26 passed / 6 failed |
| `ex3-critic-report.txt` | 3 — critic report, all five defects found | 3:11 |
| `ex4-agent.txt`, `ex4-app/` | 4 — report and the Python implementation | 2:52, 32 passed / 0 failed |
| `bonus-auditor-report.txt` | bonus — step audit, verdict NOT APPROVED | 1:45 |

## Notes for judging the recordings

- `ex3-critic-report.txt` explains defect 2 (CRIT-03) with "a service with an overly permissive boundary tolerance would still pass". That overstates it: the `beyond_tolerance_*` rows still catch a tolerance of twice `1e-9` or more. The defect is that error path row 1.7 promises rows that no longer exist. Use it as a discussion point: critics, too, need a critical reader.
- `ex2-spec.diff` names the rows differently from the reference (`tol_half_east`, `neg_ctrl_beyond_east`, …) — names are free, values and expectations match.
