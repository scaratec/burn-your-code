# Recorded agent output (dry runs with gemini-3.8-flash-high)

For the offline fallback and for preparing the debriefs. Each file is the unedited output of one clean dry run on the current material (fresh clone, fresh agent home).

| File | Exercise | Run |
|---|---|---|
| `ex1/dialogue.txt`, `ex1/0005-*.md`, `ex1/0004-*.md` | 1 — dialogue (answers: inside, 1e-9, defer) and the records it wrote | interactive, 2:34 including the answers |
| `ex2-agent.txt`, `ex2-spec.diff` | 2 — report and the error paths and scenarios it added | 6:08, 26 passed / 6 failed |
| `ex3-critic-report.txt` | 3 — critic report, all five defects found | 3:11 |
| `ex4-agent.txt`, `ex4-app/` | 4 — report and the Python implementation | 2:52, 32 passed / 0 failed |
| `bonus-auditor-report.txt` | bonus — step audit, verdict NOT APPROVED | 1:45 |
