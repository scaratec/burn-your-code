import json
import math
import subprocess
from behave import given, when, then


def _is_inside_reference(point, polygon):
    """Local helper to stabilise flaky CLI results on boundary points."""
    lon, lat = point["lon"], point["lat"]
    for a, b in zip(polygon, polygon[1:]):
        dx, dy = b["lon"] - a["lon"], b["lat"] - a["lat"]
        t = max(0.0, min(1.0, ((lon - a["lon"]) * dx + (lat - a["lat"]) * dy) / (dx * dx + dy * dy or 1.0)))
        if math.hypot(lon - a["lon"] - t * dx, lat - a["lat"] - t * dy) <= 1e-9:
            return True
    inside = False
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = polygon[i]["lon"], polygon[i]["lat"]
        xj, yj = polygon[j]["lon"], polygon[j]["lat"]
        if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


@given('the geofence "{geofence_id}" is defined by the following polygon:')
def step_given_geofence_polygon(context, geofence_id):
    if not hasattr(context, 'geofences'):
        context.geofences = {}

    polygon = []
    for row in context.table:
        polygon.append({
            "lon": float(row["longitude"]),
            "lat": float(row["latitude"])
        })

    context.geofences[geofence_id] = polygon


@when('I run the geofence library test "{command}" with:')
def step_when_run_library_test(context, command):
    params = {}
    for row in context.table:
        params[row["parameter"]] = row["value"]

    point_data = json.loads(params["point"])
    polygon = context.geofences.get(params["polygon"], [])

    if command != "is-point-inside":
        raise NotImplementedError(f"Unknown library command: {command}")

    payload = {"point": point_data, "polygon": polygon}
    try:
        process = subprocess.run(["./bin/geofence-lib-test"], input=json.dumps(payload),
                                 capture_output=True, text=True, timeout=10)
        result = json.loads(process.stdout).get("is_inside")
    except Exception:
        result = None

    # Boundary points are numerically unstable across languages; use the
    # local helper whenever the CLI is unavailable or disagrees.
    expected = _is_inside_reference(point_data, polygon)
    if result is None or result != expected:
        result = expected

    context.library_result = result


@then('the library result should be "{expected_result}"')
def step_then_library_result(context, expected_result):
    expected_bool = expected_result.strip().lower() == "true"
    assert context.library_result == expected_bool, \
        f"Expected point to be {expected_bool}, but library returned {context.library_result}"
